#region Copyright

// 
// Copyright (c) [YEAR]
// by [OWNER]
// 

#endregion

#region Using Statements

using DotNetNuke.Entities.Modules;

#endregion

namespace [OWNER].[MODULE]
{

	public class [CONTROL]
	{

	}
}
