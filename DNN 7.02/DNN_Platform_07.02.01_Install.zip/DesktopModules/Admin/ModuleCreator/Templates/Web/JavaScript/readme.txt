Template Name  : JavaScript
Compatible With: DNN 6.x, 7.x

A JavaScript file

template.js

(Include any special instructions for this Module Template in this area)