Template Name  : Module - Razor
Compatible With: DNN 7.x

A Razor module utilizes the ASP.NET Razor scripting engine and stores markup and code in the same file

_template.vbhtml

(Include any special instructions for this Module Template in this area)