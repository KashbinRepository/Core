Template Name  : Module - User Control
Compatible With: DNN 6.x, 7.x

A User Control module utilizes the ASP.NET Code File model where the user interface is stored in a file separate from the code.

template.ascx
template.ascx.vb

(Include any special instructions for this Module Template in this area)