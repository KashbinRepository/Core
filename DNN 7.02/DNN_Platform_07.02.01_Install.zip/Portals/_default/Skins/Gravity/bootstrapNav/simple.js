$(document).ready(function(e) {
//	var linkText = $('.drowpdown a').clone().html();
//	var linkValue = $('.drowpdown a').attr('href');
//	$('ul.dropdown-menu li').prepend('<li><a href="' + linkValue + '">' + linkText + "</a></li>");
});